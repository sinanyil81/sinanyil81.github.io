/**
 *  This file is part of CoverageGA
 *  
 *  CoverageGA is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or 
 *  (at your option) any later version.
 *  
 *  CoverageGA is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with CoverageGA.  If not, see <http://www.gnu.org/licenses/>. 
 */
package cga.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

import cga.data.Circle;
import cga.data.Hotspot;
import cga.data.Parameter;
import cga.data.Sensor;
import cga.data.SensorInfo;

public class SensorFileReader {

	private static Parameter createParameter(final String[] parameters) {
		Parameter parameter;
		parameter = new Parameter();
		// parameter.sensorCount = Integer.parseInt(parameters[0]);
		parameter.sensorRadius = Integer.parseInt(parameters[1]);
		parameter.setAreaWidth(Integer.parseInt(parameters[2]));
		parameter.setAreaHeight(Integer.parseInt(parameters[3]));
		parameter.kCovered = Integer.parseInt(parameters[4]);
		return parameter;
	}

	public static void main(final String[] args) {
		read("sensorler.dat");
		for (final Hotspot hs : SensorInfo.getInstance().getHotSpots()) {
			System.out.println(hs);
		}
		for (final Circle hs : SensorInfo.getInstance().getSensors()) {
			System.out.println(hs);
		}
	}

	public static void read(final File file) {
		try {
			final Vector<Hotspot> hotspots = new Vector<Hotspot>();
			final Vector<Sensor> sensors = new Vector<Sensor>();
			final BufferedReader reader = new BufferedReader(new FileReader(
					file));
			String str;
			int islem = -1;
			int sensorCounter = 0;
			Parameter parameter = null;
			while ((str = reader.readLine()) != null) {
				// Dosya sonu kontrolu
				str = str.trim();
				if (str.startsWith("EOF"))
					break;
				if (str.startsWith("HOT_SPOTS")) {
					islem = 0;
					continue;
				} else if (str.startsWith("SENSOR_INFO")) {
					islem = 1;
					continue;
				}
				// Eger yorum satiri degilse
				if (!str.startsWith("#")) {// yorum satiri degilse
					// Parametreler ilk satirda okunmali
					if (parameter == null) {
						final String[] parameters = str.split(" ");
						parameter = createParameter(parameters);
					} else {
						final String[] satir = str.split(" ");
						if (islem == 0) {
							// hot spot bilgisi
							hotspots.add(new Hotspot(0, Integer
									.parseInt(satir[0]), Integer
									.parseInt(satir[1])));
						} else if (islem == 1) {
							// Sensor bilgisi
							sensors.add(new Sensor(sensorCounter++, Integer
									.parseInt(satir[0]), Integer
									.parseInt(satir[1])));

						}
					}
				}
			}
			SensorInfo.load(parameter, hotspots, sensors);
		} catch (final IOException e) {
			e.printStackTrace();
		}
	}

	public static void read(final String filename) {
		read(new File(filename));
	}

}
