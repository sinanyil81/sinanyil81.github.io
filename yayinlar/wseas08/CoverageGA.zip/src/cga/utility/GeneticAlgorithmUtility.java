/**
 *  This file is part of CoverageGA
 *  
 *  CoverageGA is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or 
 *  (at your option) any later version.
 *  
 *  CoverageGA is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with CoverageGA.  If not, see <http://www.gnu.org/licenses/>. 
 */
package cga.utility;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.Vector;

import cga.data.Circle;
import cga.data.Hotspot;
import cga.data.Sensor;
import cga.data.SensorInfo;
import cga.data.ga.Movement;

public class GeneticAlgorithmUtility {
	private static GeneticAlgorithmUtility instance = null;

	public static GeneticAlgorithmUtility getInstance() {
		if (instance == null)
			instance = new GeneticAlgorithmUtility();
		return instance;
	}

	public static void main(final String[] args) {
		SensorFileReader.read("sensorK.dat");
		final SensorInfo si = SensorInfo.getInstance();
		GeneticAlgorithmUtility.getInstance().initImage(null);
		GeneticAlgorithmUtility.getInstance().calculateArea(si.getSensors(),
				si, "last", false);

	}

	private Graphics2D g2d;

	private BufferedImage image;

	private GeneticAlgorithmUtility() {

	}

	public Sensor applyMovement(final Sensor sensor, final Movement mi) {
		return new Sensor(sensor.getId(), sensor.getX() + mi.getXInc(), sensor
				.getY()
				+ mi.getYInc());
	}

	public void applyMovement(final Vector<Sensor> sensors,
			final Movement[] movement) {
		for (int i = 0; i < sensors.size(); i++) {
			sensors.set(i, applyMovement(sensors.get(i), movement[i]));
		}
	}

	public int calculateArea(final Vector<Sensor> sensors,
			final SensorInfo sensorInfo, final String fileNamePrefix,
			final boolean resimKaydet) {
		// background must be white
		g2d.setPaint(Color.WHITE);
		g2d.fill(new Rectangle2D.Double(0, 0, sensorInfo.parameter
				.getAreaWidth(), sensorInfo.parameter.getAreaHeight()));
		SensorDrawUtility.drawSensors(g2d, sensorInfo, sensors);

		// Draw hotspots
		g2d.setColor(Color.BLUE);
		SensorDrawUtility.drawHotspots(g2d, sensorInfo.parameter.sensorRadius,
				sensorInfo.getHotSpots());

		return SensorUtility.calculateArea(image, fileNamePrefix, resimKaydet);
	}

	public int calculateFitness(final Vector<Sensor> sensors,
			final SensorInfo sensorInfo) {
		final int coverageArea = calculateArea(sensors, sensorInfo, null, false);

		final int connectedComponentCount = countConnectedComponents(sensors);
		final int distanceBetweenConComps = calculateTotalDistanceBetweenConnectedComponents(
				connectedComponentCount, sensors);
		final int connectivityFitness = distanceBetweenConComps
				* connectedComponentCount;

		/* TODO : makaledeki algoritma tam anlamiyla gerceklestirilmeli */
		/*
		 * if (!isKCovered(sensors, sensorInfo)) return -100000000;
		 */

		if (!isKCovered2(sensors, sensorInfo))
			return -100000000;

		if (connectedComponentCount > 1)
			return -connectivityFitness;

		return coverageArea;
	}

	protected int calculateTotalDistanceBetweenConnectedComponents(
			final int connectedComponentCount, final Vector<Sensor> sensors) {
		final Vector<Sensor>[] connectedComponents = new Vector[connectedComponentCount];
		for (final Sensor sensor : sensors) {
			if (connectedComponents[sensor.getConnectedComponentNumber() - 1] == null)
				connectedComponents[sensor.getConnectedComponentNumber() - 1] = new Vector<Sensor>();
			connectedComponents[sensor.getConnectedComponentNumber() - 1]
					.add(sensor);
		}
		int totalDistance = 0;
		for (int i = 0; i < connectedComponents.length; i++) {
			for (int j = i + 1; j < connectedComponents.length; j++) {
				totalDistance += distanceBetween(connectedComponents[i],
						connectedComponents[j]);
			}
		}
		return totalDistance;
	}

	private int countConnectedComponents(final Vector<Sensor> _sensors) {
		createNeighbourhood(_sensors);

		int groupNumber = 0;

		for (final Sensor _sensor : _sensors) {
			if (_sensor.getStatus() == Sensor.WHITE) {
				dfs(_sensor, ++groupNumber);
			}
		}
		return groupNumber;
	}

	private void createNeighbourhood(final Vector<Sensor> sensors) {
		for (final Sensor sensor : sensors) {
			sensor.clearNeighbours();
			sensor.setStatus(Sensor.WHITE);
			for (final Sensor _sensor : sensors) {
				if (sensor.equals(_sensor))
					continue;
				if (sensor.connectedTo(_sensor)) {
					sensor.addNeighbour(_sensor);
				}
			}
		}
	}

	private void dfs(final Sensor _sensor, final int _connectedComponentGroup) {
		if (_sensor.getStatus() == Sensor.WHITE) {
			_sensor.setStatus(Sensor.BLACK);
			_sensor.setConnectedComponentNumber(_connectedComponentGroup);
			if (_sensor.getNeighbours() != null) {
				for (final Sensor neighbour : _sensor.getNeighbours()) {
					dfs(neighbour, _connectedComponentGroup);
				}
			}
		}
	}

	private int distanceBetween(final Vector<Sensor> group1,
			final Vector<Sensor> group2) {
		int min = Integer.MAX_VALUE;
		for (final Circle group1Sensor : group1) {
			for (final Circle group2Sensor : group2) {
				final int distance = (int) group1Sensor.getPoint().distance(
						group2Sensor.getPoint());
				if (distance < min) {
					min = distance;
				}
			}
		}
		return min;
	}

	public void initImage(final Graphics2D _g2d) {
		if (_g2d == null) {
			image = new BufferedImage(SensorInfo.getInstance().parameter
					.getAreaWidth(), SensorInfo.getInstance().parameter
					.getAreaHeight(), BufferedImage.TYPE_INT_RGB);
			g2d = image.createGraphics();
		} else {
			g2d = _g2d;
		}
	}

	protected boolean isConnected(final Vector<Sensor> sensors) {
		// final boolean isConnected = false;
		// Create graph
		createNeighbourhood(sensors);
		traverseNeighbourhood(sensors);
		for (final Sensor sensor : sensors) {
			if (sensor.getStatus() == Sensor.WHITE)
				return false;
		}
		return true;
	}

	/*
	 * Hotspot uzerinde K adet sensor olup olmadigina bakilarak karar veriliyor.
	 */
	private boolean isKCovered2(final Vector<Sensor> sensors,
			final SensorInfo sensorInfo) {

		final int kCovered = SensorInfo.getInstance().parameter.kCovered;

		// traverse all hotspots
		for (final Hotspot hotSpot : sensorInfo.getHotSpots()) {
			int covered = 0;

			for (final Sensor sensor : sensors) {
				if ((hotSpot.getX() == sensor.getX())
						&& (hotSpot.getY() == sensor.getY())) {
					covered++;
				}

			}

			if (covered < kCovered)
				return false;
		}

		return true;
	}

	protected void setImage(final Graphics2D _g2d) {
		g2d = _g2d;
	}

	private void traverseNeighbourhood(final Vector<Sensor> _sensors) {
		final Vector<Sensor> tempSensors = new Vector<Sensor>();
		tempSensors.add(_sensors.get(0));
		tempSensors.get(0).setStatus(Sensor.GRAY);
		while (tempSensors.size() > 0) {
			final Sensor sensor = tempSensors.remove(0);
			if (sensor.getNeighbours() != null) {
				for (final Sensor neighbour : sensor.getNeighbours()) {
					if (neighbour.getStatus() == Sensor.WHITE) {
						neighbour.setStatus(Sensor.GRAY);
						tempSensors.add(neighbour);
					}
				}
			}
			sensor.setStatus(Sensor.BLACK);
		}
	}

	/*
	 * private boolean isKCovered(final Vector<Sensor> sensors, final SensorInfo
	 * sensorInfo) {
	 * 
	 * final int KCoverage = SensorInfo.getInstance().parameter.kCovered;
	 * 
	 * TODO makaledeki algoritma tam anlamiyla gerceklestirilmeli // traverse
	 * all hotspots for (final Hotspot hotSpot : sensorInfo.getHotSpots()) {
	 * 
	 * if (!(getIntersectionArcCoverage(hotSpot, sensors) >= KCoverage)) return
	 * false; }
	 * 
	 * return true; }
	 */

	/*
	 * private void updateCoveredArcs(final Arc intersection, final Arc
	 * preprocessedArc, final Vector<Arc> updatedArcsVector) { // intersect
	 * intersection with the previously added arc final Arc coveredArc =
	 * intersection.getIntersection(preprocessedArc);
	 * 
	 * if (coveredArc != null) { final Arc[] difference = preprocessedArc
	 * .getIntersectionDifference(intersection);
	 * 
	 * coveredArc.setCoverage(preprocessedArc.getCoverage() + 1);
	 * updatedArcsVector.add(coveredArc);
	 * 
	 * if (difference != null) { for (final Arc element : difference) { if
	 * (element != null) { element.setCoverage(preprocessedArc.getCoverage());
	 * updatedArcsVector.add(element); } } } } else {
	 * updatedArcsVector.add(preprocessedArc); } } }
	 */
	/*
	 * private int getIntersectionArcCoverage(final Hotspot hotSpot, final
	 * Vector<Sensor> sensors) { // 2R final int radius2 =
	 * SensorInfo.getInstance().parameter.sensorRadius 2; // holds the
	 * intersection arcs between the hotspot and sensors Vector<Arc> hotSpotArcs
	 * = new Vector<Arc>(); // initially add 0-2PI Arc hotSpotArcs.add(new
	 * Arc(0f, (float) (Math.PI 2))); // traverse all sensors inside the hotSpot
	 * for (int i = 0; i < sensors.size(); i++) { // get sensor final Sensor
	 * sensor = sensors.get(i); // check distance if (hotSpot.distance(sensor) <
	 * radius2) { // temporary Vector to hold temporary hotspot - sensor //
	 * intersections final Vector<Arc> tmp = new Vector<Arc>(); // intersections
	 * Vector<Arc> intersections = new Vector<Arc>(); // intersect hotspot and
	 * sensor to get a covered Arc hotSpot.intersect(sensor, intersections); //
	 * loop hotspot intersections for (final Arc preprocessedArc : hotSpotArcs)
	 * { for (final Arc intersection : intersections) {
	 * updateCoveredArcs(intersection, preprocessedArc, tmp); } }
	 * 
	 * intersections.removeAllElements(); intersections = null;
	 * 
	 * hotSpotArcs.removeAllElements(); hotSpotArcs = null; hotSpotArcs = tmp; }
	 * }
	 * 
	 * if (checkPerimeterCovered(hotSpotArcs)) { int min = 1000;
	 * 
	 * for (final Arc arc : hotSpotArcs) { if (arc.getCoverage() < min) min =
	 * arc.getCoverage(); }
	 * 
	 * hotSpotArcs.removeAllElements(); hotSpotArcs = null;
	 * 
	 * if (min != 1000) return (min - 1); else return 0; } else {
	 * hotSpotArcs.removeAllElements(); hotSpotArcs = null;
	 * 
	 * return 0; } }
	 */
	/*
	 * private boolean checkPerimeterCovered(final Vector<Arc> intersections) {
	 * 
	 * if (intersections == null) return false;
	 * 
	 * Vector<Arc> perimeter = new Vector<Arc>(); Vector<Arc> tmp = new
	 * Vector<Arc>();
	 * 
	 * add 0-2 Pi perimeter.add(new Arc((float) 0.0, (float) (2 Math.PI)));
	 * 
	 * for (final Arc arc : intersections) { for (final Arc pe : perimeter) { //
	 * get difference final Arc[] difference =
	 * pe.getIntersectionDifference(arc); // if difference if (difference !=
	 * null) { for (final Arc element : difference) { if (element != null) {
	 * tmp.add(element); } } } }
	 * 
	 * if (perimeter != null) perimeter.removeAllElements();
	 * 
	 * perimeter = tmp; tmp = new Vector<Arc>(); }
	 * 
	 * if (perimeter.size() == 0) // System.out.println("Hotspot perimeter
	 * covered"); return true; else // System.out.println("Hotspot not perimeter
	 * covered"); return false; }
	 */

}
